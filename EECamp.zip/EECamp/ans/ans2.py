
# Execercise 2
# Find the 20th Fibonacci number
 
print('\nExcercise 2')

f_20 = None

prev, curr = 1, 1
for i in range(20 - 2):
	prev, curr = curr, prev + curr
f_20 = curr

print('The 20th Fibonacci number is: {}'.format(f_20))