
# Excercise 3
# 3n + 1 Problem: please refer to the slides

print('\nExcercise 3')

operations = 0
x = 100

while x != 1:
	if x % 2 == 0:
		x /= 2
	else:
		x = 3 * x + 1
	operations += 1

print('Number of operations to be done: {}'.format(operations))