
# Excercise 1
# Swap the values of x and y

x, y = 1, 2
print('\nExcercise 1')
print('Before swapping: {}, {}'.format(x,y))

temp = x
x = y
y = temp

print('After swapping: {}, {}'.format(x,y))
