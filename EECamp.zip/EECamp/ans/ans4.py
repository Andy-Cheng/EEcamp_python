
# Excercise 4
# Print a 10-level pyramid on your console
# Eg: A 3-level pyramid is represented as follows:

#   *
#  ***
# *****

print('\n')
for i in range(1, 10):
	print(' ' * (10 - i), end = '')
	print('*' * (2 * i - 1))

