
# Excercise 5
# Write a function that takes a string as an argument
# and returns the reversed string

# eg: reversed('hello') -> 'olleh'

def reverse(input):
	rev = ''
	l =  len(input)
	for i in range(l):
		rev += input[l - i -1]
	return rev

print(reverse('hello'))