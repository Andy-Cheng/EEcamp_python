
# Excercise 5
# Write a function that takes a string as an argument
# and returns the reversed string

# eg: reversed('hello') -> 'olleh'

# ---------- Your Code Here ---------- #
#                                      #
#                                      # 
#                                      #
#                                      #
# ------------------------------------ #