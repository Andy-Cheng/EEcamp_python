
# Excercise 3
# 3n + 1 Problem: please refer to the slides

print('Excercise 3')
operations = 0
x = 100

# ---------- Your Code Here ---------- #
#                                      #
#                                      # 
#                                      #
#                                      #
# ------------------------------------ #

print("Number of operations to be done: {}".format(operations))