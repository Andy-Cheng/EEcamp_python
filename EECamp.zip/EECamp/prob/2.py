
# Execercise 2
# Find the 20th Fibonacci number
 
print('Excercise 2')
f_20 = None

# ---------- Your Code Here ---------- #
#                                      #
#                                      # 
#                                      #
#                                      #
# ------------------------------------ #

print('The 20th Fibonacci number is: {}'.format(f_20))