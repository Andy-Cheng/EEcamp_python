
# Excercise 4
# Print a 10-level pyramid on your console
# Eg: A 3-level pyramid is represented as follows:

#   *
#  ***
# *****

# ---------- Your Code Here ---------- #
#                                      #
#                                      # 
#                                      #
#                                      #
# ------------------------------------ #

