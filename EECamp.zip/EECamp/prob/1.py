
# Excercise 1
# Swap the values of x and y

x, y = 1, 2
print('Excercise 1')
print('Before swapping: {}, {}'.format(x,y))

# ---------- Your Code Here ---------- #
#                                      #
#                                      # 
#                                      #
#                                      #
# ------------------------------------ #

print('After swapping: {}, {}'.format(x,y))
